// registry.js
//
// In a real interbank network, NIBSS holds the master list of bank codes
// and routes NIP requests to the correct bank's switch. Since we don't have
// access to NIBSS, each of our mock banks holds its own copy of this table
// so it knows which base URL to call for a given destination bank code.

export const BANK_REGISTRY = {
  '011': {
    code: '011',
    name: 'Alpha Microfinance Bank (Mock)',
    baseUrl: process.env.BANK_011_URL || 'http://localhost:3001',
  },
  '023': {
    code: '023',
    name: 'Beta Microfinance Bank (Mock)',
    baseUrl: process.env.BANK_023_URL || 'http://localhost:3002',
  },
};

export function listBanks() {
  return Object.values(BANK_REGISTRY).map(({ code, name }) => ({ code, name }));
}

export function getBank(code) {
  return BANK_REGISTRY[code] || null;
}
