// seed-config.js
// Starting demo accounts for each bank. Balances are in kobo (1 Naira = 100 kobo)
// so all money math stays in integers and avoids floating-point rounding errors.

export const SEED_ACCOUNTS = {
  '011': [
    { accountNumber: '0111234567', accountName: 'Chidinma Okafor', pin: '1234', balanceKobo: 5_000_000 }, // ₦50,000
    { accountNumber: '0111234568', accountName: 'Emeka Nwosu', pin: '1234', balanceKobo: 2_500_000 },      // ₦25,000
  ],
  '023': [
    { accountNumber: '0231234567', accountName: 'Aisha Bello', pin: '1234', balanceKobo: 3_000_000 },      // ₦30,000
    { accountNumber: '0231234568', accountName: 'Tunde Fashola', pin: '1234', balanceKobo: 1_000_000 },    // ₦10,000
  ],
};
