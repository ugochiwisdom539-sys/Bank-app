// db.js
// Uses Node's built-in node:sqlite (no npm install needed).
// Each bank instance gets its own database file - this mirrors reality,
// where every bank owns and controls its own core banking ledger.

import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export function openDb(bankCode) {
  const dbPath = path.join(__dirname, `data-bank-${bankCode}.sqlite`);
  const db = new DatabaseSync(dbPath);

  db.exec(`
    CREATE TABLE IF NOT EXISTS accounts (
      account_number TEXT PRIMARY KEY,
      account_name   TEXT NOT NULL,
      pin            TEXT NOT NULL,
      balance_kobo   INTEGER NOT NULL DEFAULT 0,
      status         TEXT NOT NULL DEFAULT 'active',
      created_at     TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id                     TEXT PRIMARY KEY,
      account_number         TEXT NOT NULL,
      entry_type             TEXT NOT NULL,   -- debit | credit
      direction              TEXT NOT NULL,   -- local | outward | inward
      amount_kobo            INTEGER NOT NULL,
      balance_after_kobo     INTEGER NOT NULL,
      counterparty_bank_code TEXT,
      counterparty_account   TEXT,
      counterparty_name      TEXT,
      narration              TEXT,
      status                 TEXT NOT NULL,   -- successful | pending | reversed | failed
      session_id             TEXT NOT NULL,
      created_at             TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS idempotency (
      session_id    TEXT PRIMARY KEY,
      response_json TEXT NOT NULL,
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  return db;
}

export function seedIfEmpty(db, seedAccounts) {
  const { c } = db.prepare('SELECT COUNT(*) AS c FROM accounts').get();
  if (c > 0) return;
  const insert = db.prepare(
    `INSERT INTO accounts (account_number, account_name, pin, balance_kobo, status)
     VALUES (?, ?, ?, ?, 'active')`
  );
  for (const acc of seedAccounts) {
    insert.run(acc.accountNumber, acc.accountName, acc.pin, acc.balanceKobo);
  }
}

export function listAccountsBasic(db) {
  return db.prepare('SELECT account_number, account_name FROM accounts ORDER BY account_number').all();
}

export function getAccount(db, accountNumber) {
  return db.prepare('SELECT * FROM accounts WHERE account_number = ?').get(accountNumber) || null;
}

export function getTransactions(db, accountNumber, limit = 50) {
  return db
    .prepare(
      `SELECT * FROM transactions WHERE account_number = ?
       ORDER BY created_at DESC, rowid DESC LIMIT ?`
    )
    .all(accountNumber, limit);
}

export function recordTransaction(db, tx) {
  db.prepare(
    `INSERT INTO transactions
      (id, account_number, entry_type, direction, amount_kobo, balance_after_kobo,
       counterparty_bank_code, counterparty_account, counterparty_name, narration, status, session_id)
     VALUES (@id, @account_number, @entry_type, @direction, @amount_kobo, @balance_after_kobo,
       @counterparty_bank_code, @counterparty_account, @counterparty_name, @narration, @status, @session_id)`
  ).run(tx);
}

export function updateTransactionStatus(db, id, status) {
  db.prepare('UPDATE transactions SET status = ? WHERE id = ?').run(status, id);
}

export function getIdempotentResponse(db, sessionId) {
  const row = db.prepare('SELECT response_json FROM idempotency WHERE session_id = ?').get(sessionId);
  return row ? JSON.parse(row.response_json) : null;
}

export function saveIdempotentResponse(db, sessionId, response) {
  db.prepare('INSERT OR REPLACE INTO idempotency (session_id, response_json) VALUES (?, ?)').run(
    sessionId,
    JSON.stringify(response)
  );
}

// Atomic debit: throws if insufficient funds / account missing / inactive.
// Returns the new balance.
export function debitAccount(db, accountNumber, amountKobo) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const acc = getAccount(db, accountNumber);
    if (!acc) throw new Error('ACCOUNT_NOT_FOUND');
    if (acc.status !== 'active') throw new Error('ACCOUNT_INACTIVE');
    if (acc.balance_kobo < amountKobo) throw new Error('INSUFFICIENT_FUNDS');

    const newBalance = acc.balance_kobo - amountKobo;
    db.prepare('UPDATE accounts SET balance_kobo = ? WHERE account_number = ?').run(
      newBalance,
      accountNumber
    );
    db.exec('COMMIT');
    return newBalance;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

// Atomic credit: throws if account missing / inactive. Returns the new balance.
export function creditAccount(db, accountNumber, amountKobo) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const acc = getAccount(db, accountNumber);
    if (!acc) throw new Error('ACCOUNT_NOT_FOUND');
    if (acc.status !== 'active') throw new Error('ACCOUNT_INACTIVE');

    const newBalance = acc.balance_kobo + amountKobo;
    db.prepare('UPDATE accounts SET balance_kobo = ? WHERE account_number = ?').run(
      newBalance,
      accountNumber
    );
    db.exec('COMMIT');
    return newBalance;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}
