const ACCENTS = {
  '011': { accent: '#1c7c72', ink: '#0b3a35', mark: 'A' },
  '023': { accent: '#c97a2b', ink: '#5c3413', mark: 'B' },
};

const state = {
  bankCode: null,
  bankName: null,
  account: null, // { accountNumber, pin }
};

const $ = (id) => document.getElementById(id);

async function api(path, opts = {}) {
  const res = await fetch(path, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || data.reason || 'REQUEST_FAILED');
    err.data = data;
    throw err;
  }
  return data;
}

function money(naira) {
  return Number(naira).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

async function init() {
  const info = await api('/api/bank-info');
  state.bankCode = info.bankCode;
  state.bankName = info.bankName;

  const theme = ACCENTS[info.bankCode] || { accent: '#1c7c72', ink: '#0b3a35', mark: '•' };
  document.documentElement.style.setProperty('--accent', theme.accent);
  document.documentElement.style.setProperty('--accent-ink', theme.ink);
  $('bankMark').textContent = theme.mark;
  $('bankName').textContent = info.bankName;
  $('bankCodeLabel').textContent = `Bank code ${info.bankCode}`;
  document.title = info.bankName;

  await populateLoginAccounts();
  await populateDestinationBanks();
  bindEvents();
}

async function populateLoginAccounts() {
  const accounts = await api('/api/accounts');
  const select = $('accountSelect');
  select.innerHTML = accounts
    .map((a) => `<option value="${a.accountNumber}">${a.accountName} — ${a.accountNumber}</option>`)
    .join('');
}

async function populateDestinationBanks() {
  const banks = await api('/api/banks');
  const select = $('destBank');
  select.innerHTML = banks
    .map((b) => `<option value="${b.code}">${b.name} (${b.code})</option>`)
    .join('');
}

function bindEvents() {
  $('loginBtn').addEventListener('click', onLogin);
  $('logoutBtn').addEventListener('click', onLogout);
  $('destAccount').addEventListener('blur', onNameEnquiry);
  $('transferBtn').addEventListener('click', onTransfer);
}

async function onLogin() {
  const accountNumber = $('accountSelect').value;
  const pin = $('pinInput').value.trim();
  const errorEl = $('loginError');
  errorEl.hidden = true;

  if (!pin) {
    errorEl.textContent = 'Enter the PIN for the selected account.';
    errorEl.hidden = false;
    return;
  }

  try {
    const acc = await api(`/api/accounts/${accountNumber}?pin=${encodeURIComponent(pin)}`);
    state.account = { accountNumber: acc.accountNumber, pin };
    $('loginView').hidden = true;
    $('dashboardView').hidden = false;
    $('logoutBtn').hidden = false;
    await refreshDashboard();
  } catch (err) {
    errorEl.textContent = err.data?.error === 'INVALID_PIN' ? 'Incorrect PIN.' : 'Could not sign in.';
    errorEl.hidden = false;
  }
}

function onLogout() {
  state.account = null;
  $('pinInput').value = '';
  $('loginView').hidden = false;
  $('dashboardView').hidden = true;
  $('logoutBtn').hidden = true;
  $('transferResult').hidden = true;
  $('nameEnquiryResult').hidden = true;
}

async function refreshDashboard() {
  const acc = await api(`/api/accounts/${state.account.accountNumber}?pin=${encodeURIComponent(state.account.pin)}`);
  $('balanceAmount').textContent = money(acc.balanceNaira);
  $('acctName').textContent = acc.accountName;
  $('acctNumber').textContent = acc.accountNumber;

  const txs = await api(`/api/accounts/${state.account.accountNumber}/transactions?pin=${encodeURIComponent(state.account.pin)}`);
  renderLedger(txs);
}

function renderLedger(txs) {
  const list = $('ledgerList');
  if (!txs.length) {
    list.innerHTML = '<div class="empty-state">No transactions yet.</div>';
    return;
  }
  list.innerHTML = txs
    .map((t) => {
      const isCredit = t.type === 'credit';
      const sign = isCredit ? '+' : '−';
      const who = t.counterpartyName || t.counterpartyAccount || 'Account';
      const statusTag = t.status !== 'successful' ? `<span class="tag">${t.status}</span>` : '';
      const routeTag = t.direction === 'local' ? '' : `<span class="tag">${t.direction}</span>`;
      return `
        <div class="ledger-row">
          <div class="ledger-row__left">
            <div class="ledger-row__narration">${t.narration || (isCredit ? 'Received from' : 'Sent to') + ' ' + who}</div>
            <div class="ledger-row__sub">${new Date(t.createdAt).toLocaleString()} · Bal ₦${money(t.balanceAfterNaira)}${statusTag}${routeTag}</div>
          </div>
          <div class="ledger-row__amount ${isCredit ? 'credit' : 'debit'}">${sign}₦${money(t.amountNaira)}</div>
        </div>`;
    })
    .join('');
}

async function onNameEnquiry() {
  const bankCode = $('destBank').value;
  const accountNumber = $('destAccount').value.trim();
  const box = $('nameEnquiryResult');
  if (!accountNumber) {
    box.hidden = true;
    return;
  }

  const bank = (await api('/api/banks')).find((b) => b.code === bankCode);

  try {
    let result;
    if (bankCode === state.bankCode) {
      result = await api(`/api/name-enquiry/${accountNumber}`);
    } else {
      // In reality NIBSS performs this lookup. Here we call the destination
      // bank's own name-enquiry endpoint directly, which is exposed for that
      // purpose in this mock.
      const res = await fetch(`${bank.baseUrl}/api/name-enquiry/${accountNumber}`);
      if (!res.ok) throw new Error('NOT_FOUND');
      result = await res.json();
    }
    box.textContent = `✓ ${result.accountName} — ${result.bankName}`;
    box.classList.remove('is-error');
    box.hidden = false;
  } catch {
    box.textContent = '✕ Could not verify this account number.';
    box.classList.add('is-error');
    box.hidden = false;
  }
}

async function onTransfer() {
  const btn = $('transferBtn');
  const resultEl = $('transferResult');
  resultEl.hidden = true;

  const payload = {
    fromAccountNumber: state.account.accountNumber,
    pin: $('transferPin').value.trim(),
    destinationBankCode: $('destBank').value,
    destinationAccountNumber: $('destAccount').value.trim(),
    amountNaira: Number($('amountInput').value),
    narration: $('narrationInput').value.trim(),
  };

  if (!payload.destinationAccountNumber || !payload.amountNaira || !payload.pin) {
    resultEl.textContent = 'Fill in account number, amount, and PIN.';
    resultEl.className = 'result is-error';
    resultEl.hidden = false;
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Sending…';

  try {
    const result = await api('/api/transfers', { method: 'POST', body: JSON.stringify(payload) });
    resultEl.textContent = `Transfer successful. New balance ₦${money(result.newSourceBalanceNaira)}.`;
    resultEl.className = 'result is-success';
    resultEl.hidden = false;
    $('destAccount').value = '';
    $('amountInput').value = '';
    $('narrationInput').value = '';
    $('transferPin').value = '';
    $('nameEnquiryResult').hidden = true;
    await refreshDashboard();
  } catch (err) {
    const reason = err.data?.reason || err.data?.error || 'Transfer failed.';
    resultEl.textContent = `Not completed: ${reason}`;
    resultEl.className = 'result is-error';
    resultEl.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = 'Send transfer';
  }
}

init().catch((err) => {
  console.error(err);
  document.body.innerHTML = '<p style="padding:24px;font-family:sans-serif">Failed to load. Is the server running?</p>';
});
