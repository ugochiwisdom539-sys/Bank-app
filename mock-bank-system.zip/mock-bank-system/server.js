// server.js
//
// A single codebase that runs as ANY bank in the mock network - which bank
// it is depends on the BANK_CODE env var. Run it twice (different BANK_CODE
// + PORT) to get two independent "banks" that talk to each other over HTTP,
// the same way real banks talk to each other through NIBSS.
//
// Flow this simulates:
//   Local transfer   -> same bank, both accounts on this DB: single atomic move.
//   Outward transfer -> debit here, then call the OTHER bank's inward-transfer
//                        endpoint (stands in for "send to NIBSS, NIBSS routes it").
//   Inward transfer  -> another bank calling US to credit one of our accounts.
//
// Built entirely on Node's http + node:sqlite - no npm install required.

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';

import { openDb, seedIfEmpty, getAccount, getTransactions, recordTransaction,
         updateTransactionStatus, getIdempotentResponse, saveIdempotentResponse,
         debitAccount, creditAccount, listAccountsBasic } from './db.js';
import { BANK_REGISTRY, listBanks, getBank } from './registry.js';
import { SEED_ACCOUNTS } from './seed-config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const BANK_CODE = process.env.BANK_CODE || '011';
const PORT = Number(process.env.PORT) || (BANK_CODE === '011' ? 3001 : 3002);
const SELF = getBank(BANK_CODE);

if (!SELF) {
  console.error(`Unknown BANK_CODE "${BANK_CODE}". Add it to registry.js first.`);
  process.exit(1);
}

const db = openDb(BANK_CODE);
seedIfEmpty(db, SEED_ACCOUNTS[BANK_CODE] || []);

// ---------- small helpers ----------

function sendJson(res, statusCode, body) {
  const payload = JSON.stringify(body);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload),
  });
  res.end(payload);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (chunk) => {
      raw += chunk;
      if (raw.length > 1_000_000) req.destroy(); // basic guard against huge bodies
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        reject(new Error('INVALID_JSON'));
      }
    });
    req.on('error', reject);
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
};

function serveStatic(req, res, pathname) {
  const rel = pathname === '/' ? '/index.html' : pathname;
  const filePath = path.join(__dirname, 'public', rel);
  if (!filePath.startsWith(path.join(__dirname, 'public'))) return notFound(res);

  fs.readFile(filePath, (err, data) => {
    if (err) return notFound(res);
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

function notFound(res) {
  sendJson(res, 404, { error: 'NOT_FOUND' });
}

function toPublicAccount(acc) {
  return {
    accountNumber: acc.account_number,
    accountName: acc.account_name,
    balanceKobo: acc.balance_kobo,
    balanceNaira: acc.balance_kobo / 100,
    status: acc.status,
    bankCode: BANK_CODE,
    bankName: SELF.name,
  };
}

// ---------- route handlers ----------

async function handleNameEnquiry(req, res, accountNumber) {
  const acc = getAccount(db, accountNumber);
  if (!acc || acc.status !== 'active') {
    return sendJson(res, 404, { error: 'ACCOUNT_NOT_FOUND' });
  }
  sendJson(res, 200, {
    accountNumber: acc.account_number,
    accountName: acc.account_name,
    bankCode: BANK_CODE,
    bankName: SELF.name,
  });
}

async function handleGetAccount(req, res, accountNumber, query) {
  const acc = getAccount(db, accountNumber);
  if (!acc) return sendJson(res, 404, { error: 'ACCOUNT_NOT_FOUND' });
  // Simple demo auth: PIN passed as query param. Not remotely production-grade -
  // a real app would use a signed session token, never a PIN on every request.
  if (query.get('pin') !== acc.pin) return sendJson(res, 401, { error: 'INVALID_PIN' });
  sendJson(res, 200, toPublicAccount(acc));
}

async function handleGetTransactions(req, res, accountNumber, query) {
  const acc = getAccount(db, accountNumber);
  if (!acc) return sendJson(res, 404, { error: 'ACCOUNT_NOT_FOUND' });
  if (query.get('pin') !== acc.pin) return sendJson(res, 401, { error: 'INVALID_PIN' });
  const txs = getTransactions(db, accountNumber).map((t) => ({
    id: t.id,
    type: t.entry_type,
    direction: t.direction,
    amountNaira: t.amount_kobo / 100,
    balanceAfterNaira: t.balance_after_kobo / 100,
    counterpartyBank: t.counterparty_bank_code,
    counterpartyAccount: t.counterparty_account,
    counterpartyName: t.counterparty_name,
    narration: t.narration,
    status: t.status,
    sessionId: t.session_id,
    createdAt: t.created_at,
  }));
  sendJson(res, 200, txs);
}

// Another bank calling US to credit one of our accounts.
async function handleInwardTransfer(req, res) {
  let body;
  try {
    body = await readJsonBody(req);
  } catch {
    return sendJson(res, 400, { status: 'failed', reason: 'INVALID_JSON' });
  }

  const { sessionId, destinationAccountNumber, amountKobo, senderAccountNumber,
          senderName, senderBankCode, narration } = body;

  if (!sessionId || !destinationAccountNumber || !amountKobo || amountKobo <= 0) {
    return sendJson(res, 400, { status: 'failed', reason: 'MISSING_OR_INVALID_FIELDS' });
  }

  // Idempotency: if we've already processed this session, replay the same
  // response instead of crediting twice (this is exactly why NIBSS uses a
  // sessionID on every NIP request - retries must never double-credit).
  const existing = getIdempotentResponse(db, sessionId);
  if (existing) return sendJson(res, 200, existing);

  let response;
  try {
    const newBalance = creditAccount(db, destinationAccountNumber, amountKobo);
    const txId = randomUUID();
    recordTransaction(db, {
      id: txId,
      account_number: destinationAccountNumber,
      entry_type: 'credit',
      direction: 'inward',
      amount_kobo: amountKobo,
      balance_after_kobo: newBalance,
      counterparty_bank_code: senderBankCode || null,
      counterparty_account: senderAccountNumber || null,
      counterparty_name: senderName || null,
      narration: narration || null,
      status: 'successful',
      session_id: sessionId,
    });
    response = { status: 'success', sessionId, destinationAccountNumber, creditedKobo: amountKobo };
  } catch (err) {
    const reason = err.message || 'UNKNOWN_ERROR';
    response = { status: 'failed', sessionId, reason };
  }

  saveIdempotentResponse(db, sessionId, response);
  sendJson(res, response.status === 'success' ? 200 : 422, response);
}

// A customer of THIS bank initiating a transfer - could be local or interbank.
async function handleInitiateTransfer(req, res) {
  let body;
  try {
    body = await readJsonBody(req);
  } catch {
    return sendJson(res, 400, { error: 'INVALID_JSON' });
  }

  const { fromAccountNumber, pin, destinationBankCode, destinationAccountNumber,
          amountNaira, narration } = body;

  if (!fromAccountNumber || !pin || !destinationBankCode || !destinationAccountNumber || !amountNaira) {
    return sendJson(res, 400, { error: 'MISSING_FIELDS' });
  }
  if (amountNaira <= 0) return sendJson(res, 400, { error: 'INVALID_AMOUNT' });

  const amountKobo = Math.round(amountNaira * 100);

  const source = getAccount(db, fromAccountNumber);
  if (!source) return sendJson(res, 404, { error: 'SOURCE_ACCOUNT_NOT_FOUND' });
  if (source.pin !== pin) return sendJson(res, 401, { error: 'INVALID_PIN' });
  if (source.status !== 'active') return sendJson(res, 403, { error: 'SOURCE_ACCOUNT_INACTIVE' });
  if (source.balance_kobo < amountKobo) return sendJson(res, 422, { error: 'INSUFFICIENT_FUNDS' });

  const sessionId = randomUUID();

  // ----- Case 1: same bank -> pure local transfer, single atomic move -----
  if (destinationBankCode === BANK_CODE) {
    const dest = getAccount(db, destinationAccountNumber);
    if (!dest || dest.status !== 'active') {
      return sendJson(res, 404, { error: 'DESTINATION_ACCOUNT_NOT_FOUND' });
    }
    if (dest.account_number === source.account_number) {
      return sendJson(res, 400, { error: 'CANNOT_TRANSFER_TO_SELF' });
    }

    const newSourceBalance = debitAccount(db, fromAccountNumber, amountKobo);
    recordTransaction(db, {
      id: randomUUID(), account_number: fromAccountNumber, entry_type: 'debit', direction: 'local',
      amount_kobo: amountKobo, balance_after_kobo: newSourceBalance,
      counterparty_bank_code: BANK_CODE, counterparty_account: destinationAccountNumber,
      counterparty_name: dest.account_name, narration: narration || null,
      status: 'successful', session_id: sessionId,
    });

    const newDestBalance = creditAccount(db, destinationAccountNumber, amountKobo);
    recordTransaction(db, {
      id: randomUUID(), account_number: destinationAccountNumber, entry_type: 'credit', direction: 'local',
      amount_kobo: amountKobo, balance_after_kobo: newDestBalance,
      counterparty_bank_code: BANK_CODE, counterparty_account: fromAccountNumber,
      counterparty_name: source.account_name, narration: narration || null,
      status: 'successful', session_id: sessionId,
    });

    return sendJson(res, 200, {
      status: 'successful', sessionId, type: 'local',
      newSourceBalanceNaira: newSourceBalance / 100,
    });
  }

  // ----- Case 2: different bank -> outward interbank transfer -----
  const destBank = getBank(destinationBankCode);
  if (!destBank) return sendJson(res, 400, { error: 'UNKNOWN_DESTINATION_BANK' });

  // Debit first and mark pending - this is the point of no return locally.
  const newSourceBalance = debitAccount(db, fromAccountNumber, amountKobo);
  const txId = randomUUID();
  recordTransaction(db, {
    id: txId, account_number: fromAccountNumber, entry_type: 'debit', direction: 'outward',
    amount_kobo: amountKobo, balance_after_kobo: newSourceBalance,
    counterparty_bank_code: destinationBankCode, counterparty_account: destinationAccountNumber,
    counterparty_name: null, narration: narration || null,
    status: 'pending', session_id: sessionId,
  });

  // Call the destination bank's inward-transfer endpoint - this call is what
  // NIBSS's NIP switch does internally between two real banks.
  try {
    const resp = await fetch(`${destBank.baseUrl}/api/inward-transfer`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionId,
        destinationAccountNumber,
        amountKobo,
        senderAccountNumber: fromAccountNumber,
        senderName: source.account_name,
        senderBankCode: BANK_CODE,
        narration: narration || null,
      }),
    });
    const result = await resp.json();

    if (resp.ok && result.status === 'success') {
      updateTransactionStatus(db, txId, 'successful');
      return sendJson(res, 200, {
        status: 'successful', sessionId, type: 'interbank',
        newSourceBalanceNaira: newSourceBalance / 100,
      });
    }

    // Destination rejected it (e.g. invalid account) - reverse our debit.
    const reversedBalance = creditAccount(db, fromAccountNumber, amountKobo);
    updateTransactionStatus(db, txId, 'reversed');
    recordTransaction(db, {
      id: randomUUID(), account_number: fromAccountNumber, entry_type: 'credit', direction: 'outward',
      amount_kobo: amountKobo, balance_after_kobo: reversedBalance,
      counterparty_bank_code: destinationBankCode, counterparty_account: destinationAccountNumber,
      counterparty_name: null, narration: `Reversal: ${result.reason || 'transfer failed'}`,
      status: 'successful', session_id: sessionId,
    });
    return sendJson(res, 422, {
      status: 'reversed', sessionId, reason: result.reason || 'DESTINATION_REJECTED',
      newSourceBalanceNaira: reversedBalance / 100,
    });
  } catch (err) {
    // Destination bank unreachable (e.g. its server isn't running) - reverse.
    const reversedBalance = creditAccount(db, fromAccountNumber, amountKobo);
    updateTransactionStatus(db, txId, 'reversed');
    recordTransaction(db, {
      id: randomUUID(), account_number: fromAccountNumber, entry_type: 'credit', direction: 'outward',
      amount_kobo: amountKobo, balance_after_kobo: reversedBalance,
      counterparty_bank_code: destinationBankCode, counterparty_account: destinationAccountNumber,
      counterparty_name: null, narration: 'Reversal: destination bank unreachable',
      status: 'successful', session_id: sessionId,
    });
    return sendJson(res, 502, {
      status: 'reversed', sessionId, reason: 'DESTINATION_BANK_UNREACHABLE',
      newSourceBalanceNaira: reversedBalance / 100,
    });
  }
}

// ---------- router ----------

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const { pathname, searchParams } = url;
  console.log(`[${SELF.name}] ${req.method} ${pathname}`);

  try {
    if (req.method === 'GET' && pathname === '/api/bank-info') {
      return sendJson(res, 200, { bankCode: BANK_CODE, bankName: SELF.name, port: PORT });
    }
    if (req.method === 'GET' && pathname === '/api/banks') {
      return sendJson(res, 200, listBanks());
    }
    // Demo-only convenience for the login dropdown. A real bank app would
    // never expose an account listing without authentication.
    if (req.method === 'GET' && pathname === '/api/accounts') {
      const rows = listAccountsBasic(db).map((r) => ({
        accountNumber: r.account_number,
        accountName: r.account_name,
      }));
      return sendJson(res, 200, rows);
    }

    let m;
    if (req.method === 'GET' && (m = pathname.match(/^\/api\/name-enquiry\/([^/]+)$/))) {
      return await handleNameEnquiry(req, res, decodeURIComponent(m[1]));
    }
    if (req.method === 'GET' && (m = pathname.match(/^\/api\/accounts\/([^/]+)\/transactions$/))) {
      return await handleGetTransactions(req, res, decodeURIComponent(m[1]), searchParams);
    }
    if (req.method === 'GET' && (m = pathname.match(/^\/api\/accounts\/([^/]+)$/))) {
      return await handleGetAccount(req, res, decodeURIComponent(m[1]), searchParams);
    }
    if (req.method === 'POST' && pathname === '/api/transfers') {
      return await handleInitiateTransfer(req, res);
    }
    if (req.method === 'POST' && pathname === '/api/inward-transfer') {
      return await handleInwardTransfer(req, res);
    }
    if (req.method === 'GET') {
      return serveStatic(req, res, pathname);
    }
    return notFound(res);
  } catch (err) {
    console.error(err);
    sendJson(res, 500, { error: 'INTERNAL_ERROR', detail: err.message });
  }
});

server.listen(PORT, () => {
  console.log(`\n${SELF.name} (code ${SELF.code}) listening on http://localhost:${PORT}`);
  console.log(`Open http://localhost:${PORT} in your browser.\n`);
});
